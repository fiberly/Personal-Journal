<?php

// Connection details
$servername = "localhost"; 
$username = "root"; // Your MySQL username
$password = "test"; // Your MySQL password
$dbname = "journal"; // Your database name

// Create a connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check the connection
if ($conn->connect_error) {
    die("Connection Failed: " . $conn->connect_error);
}

// Handle form submissions
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['journalEntry'])) {
    $title = $conn->real_escape_string(trim($_POST['titleInput'])); // Get the title
    echo "<br>";
    $text = $conn->real_escape_string(trim($_POST['journalEntry']));
    $image_path = "";

// image upload logic
    if (isset($_FILES['image']) && $_FILES['image']['error'] == 0) { 
        
        // determine where to store the image
        $target_dir = "photoUploads/";
        $target_file = $target_dir . basename($_FILES['image']['name']);

        // move uploaded file to the target directory
        if (move_uploaded_file($_FILES['image']['tmp_name'], $target_file)) {
            $image_path = $target_file;
        }
    }

    // Insert journal entry into the database
    $sql = "INSERT INTO journals (title, content, image_path) VALUES ('$title', '$text', '$image_path')";
    
    if ($conn->query($sql) === TRUE) {
        echo "new journal entry created";
        //redirect back to the Journal
        header("Location: Journal.php"); // Redirect after successful insertion
        exit();
    } else {
        echo "Error: " . $conn->error;
    }
}

$conn->close();
?>