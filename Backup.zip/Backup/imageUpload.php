<?php

$target_dir = "photoUploads/";
$image_path = "";

//ensure target directory exists
if (!is_dir($target_dir)) {
    mkdir($target_dir, 0777, true); // creates the directory if the directory does not exist
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {

    //check if the image file is uploaded
    if (isset($_FILES['image']) && $_FILES['image']['error'] == 0) {

        $original_filename = basename($_FILES["image"]["name"]);
        $file_extension = strtolower(pathinfo($original_filename, PATHINFO_EXTENSION));

            // sanitize the filename to avoid special characters
        $sanitized_filename = preg_replace("/[^a-zA-Z0-9-_\.]/", "-", $original_filename);

        // create a unique filename to avoid overwriting files
        $target_file = $target_dir . uniqid() . '-' . $sanitized_filename;
        $uploadOk = 1;
    


        // check if the image is a valid image file
        $check = getimagesize($_FILES["image"]["tmp_name"]);
        if ($check === false) {
            echo json_encode(['error' => "File is not an image and needs to be an image."]);
            $uploadOk = 0;
        }

        // Validate file size 10mb limit
        if ($_FILES["image"]["size"] > 10000000) { 
            echo json_encode(['error' => "file size is too large, the file must be 10 megabytese or under."]);
            $uploadOk = 0;
        }

        // proceed with uplocad if the checks pass
        if ($uploadOk == 1) {
            if (move_uploaded_file($_FILES["image"]["tmp_name"], $target_file)) {
                $image_path = $target_file; // save the path for immediate use
                echo json_encode(['imagePath' => $image_path]); // return JSON response with an image path
            } else {
                echo json_encode(['error' => "Apologies, there was an error when trying to upload the file."]);
            }
        }

    } else { 
        echo json_encode(['error' => "No file was uploaded or there was an error with the photo upload."]);
    }
} 

echo $image_path;
?>